# astra_core/questions/question_answerer.py
from astra_interfaces.influence import save_mind  # Import save_mind from influence.py
from .question_flagger import flag_unresolved_question

def self_answer_question(mind_data):
    """Process Astra's questions and flag any unresolved ones."""
    unresolved_questions = mind_data.get("unresolved_questions", [])
    unanswered_questions = []  # Keep track of unanswered but not removed questions

    # Debugging: Print current self_questions
    print(f"Processing {len(mind_data['self_questions'])} self-questions.")
    
    # Answering logic...
    for question in mind_data["self_questions"]:
        print(f"Checking question: {question['question']}")
        if flag_unresolved_question(question["question"], mind_data):
            # If question is unresolved, don't remove it, just mark it
            print(f"Question is unresolved: {question['question']}")
            unanswered_questions.append(question)
        else:
            # Process resolved questions (answers found)
            print(f"Question resolved: {question['question']}")
    
    # Update the mind_data with unresolved and unanswered questions
    mind_data["self_questions"] = unanswered_questions  # Keep unresolved in the same list
    mind_data["unresolved_questions"] = unresolved_questions  # Track unresolved separately

    # Save the updated mind data
    save_mind(mind_data)
    
    # Return unanswered questions for further processing or review
    return unanswered_questions
