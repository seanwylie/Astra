# astra_core/questions/question_tracker.py

def track_unresolved_questions(mind_data):
    """Tracks unresolved questions and their progress."""
    unresolved_questions = mind_data.get("unresolved_questions", [])

    # Debugging: Print number of unresolved questions
    print(f"Tracking unresolved questions...")
    print(f"⚠ There are {len(unresolved_questions)} unresolved questions!")

    # Process unresolved questions (this could involve prioritization logic, review, etc.)
    for question in unresolved_questions:
        print(f"🔍 Unresolved Question: {question['question']}")
        # You could add more tracking logic here, e.g., flagging for review or prioritization

    # Return updated mind_data (in case further processing is done to it)
    return mind_data
