# In astra_core/questions/question_generator.py

import random
import time
from astra_core.questions.question_flagger import flag_unresolved_question
from astra_core.knowledge import knowledge_manager
from astra_core.config_loader import load_config

def generate_questions(reflection, mind_data):
    """Generates structured questions based on Astra's reflection, ensuring variety and avoiding redundancy."""
    
    # Move the import inside the function to avoid circular import at module level
    from astra_core.questions.question_utils import categorize_questions

    question_templates = list(set(general_config.get("question_templates", [])))
    deep_thought_templates = list(set(config_soul.get("deep_thought_questions", [])))
    principles = config_soul.get("soul", {}).get("principles", {})
    reflection_modifiers = list(set(general_config.get("reflection_style_modifiers", {}).values()))

    num_questions = random.randint(3, 6)
    generated_questions = []

    while len(generated_questions) < num_questions // 2 and question_templates:
        question_text = f"{random.choice(question_templates)}".strip()
        modifier = random.choice(reflection_modifiers)
        full_question = f"{question_text} {modifier}"
        context_summary = f"This question was generated from a reflection on: {reflection[:100]}..."

        generated_questions.append({
            "question": full_question,
            "source": "reflection",
            "context_summary": context_summary,
            "related_knowledge": reflection[:150],
            "attempted_answers": []
        })

    while len(generated_questions) < num_questions and deep_thought_templates:
        question_text = f"{random.choice(deep_thought_templates)}".strip()
        principle_key = random.choice(list(principles.keys()))
        principle_desc = principles[principle_key]["description"]
        full_question = f"{question_text} How does this relate to my principle of {principle_key.replace('_', ' ')}: {principle_desc}?"
        context_summary = f"This question explores Astra's core principle: {principle_key.replace('_', ' ')}."

        generated_questions.append({
            "question": full_question,
            "source": "soul_principle",
            "context_summary": context_summary,
            "related_knowledge": principle_desc,
            "attempted_answers": []
        })

    print("✅ Debug: Generated full-length questions with context:")
    for q in generated_questions:
        print(f"- {q['question']} (Source: {q['source']}, Context: {q['context_summary']}, Related Knowledge: {q['related_knowledge'][:50]}...)")

    return categorize_questions(filter_questions(mind_data, generated_questions))
