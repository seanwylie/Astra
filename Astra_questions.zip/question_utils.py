import sys
import os

# Add the parent directory of astra_core (astra_reflections) to sys.path so Python can find `astra_core`
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from sentence_transformers import SentenceTransformer, util
from astra_core.config_loader import load_config

# Load question categories and sample questions from the correct config file
config_file_path = os.path.join(os.path.dirname(__file__), '../config/question_config.json')
question_config = load_config(config_file_path)  # Use the absolute path to the config file

# Debugging: Check the loaded config structure
print(f"Loaded Config: {question_config}")

# Initialize the Sentence-BERT model
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')

def generate_category_embeddings(question_config):
    """Generate embeddings for each category's sample questions."""
    category_embeddings = {}

    for category, details in question_config["question_categories"].items():
        sample_questions = details["sample_questions"]
        # Debugging: Print sample questions being processed
        print(f"Generating embeddings for category: {category}")
        print(f"Sample Questions: {sample_questions}")
        
        category_embeddings[category] = model.encode(sample_questions, convert_to_tensor=True)

    return category_embeddings

# Generate embeddings for all categories
category_embeddings = generate_category_embeddings(question_config)

def categorize_question(question, category_embeddings):
    """Categorize an incoming question based on semantic similarity to category embeddings."""
    # Encode the incoming question
    question_embedding = model.encode(question, convert_to_tensor=True)
    
    # Compare the question with all category embeddings using cosine similarity
    similarities = {}
    for category, embeddings in category_embeddings.items():
        similarities[category] = util.pytorch_cos_sim(question_embedding, embeddings).mean().item()

    # Debugging: Print similarities for each category
    print(f"Similarities: {similarities}")
    
    # Return the category with the highest similarity
    best_category = max(similarities, key=similarities.get)
    return best_category

# Sample question for testing
question = "What is the meaning of life?"

# Categorize the question
category = categorize_question(question, category_embeddings)

# Output the result
print(f"Question: {question}")
print(f"Category: {category}")
