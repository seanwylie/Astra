# In question_flagger.py
from astra_core.config_loader import load_config

# Load configuration files
question_config = load_config("question_config")
# astra_core/questions/question_flagger.py

def flag_unresolved_question(questions, mind_data):
    """Flags a question as unresolved if it cannot be answered using Astra's knowledge."""
    unresolved_questions = mind_data.get("unresolved_questions", [])
    valid_questions = []

    for q in questions:
        # ✅ Ensure only full questions are processed
        if isinstance(q, dict) and "question" in q:
            question = q["question"].strip()
        elif isinstance(q, str):
            question = q.strip()
        else:
            print(f"⚠ Unexpected question format: {q}")
            continue

        if len(question) < 5:  # ✅ Ignore short nonsense inputs
            print(f"⚠ Ignoring invalid question: {question}")
            continue

        if question in question_config["question_categories"]:  # ✅ Ignore category names
            print(f"⚠ Skipping category name mistaken as question: {question}")
            continue

        print(f"🔍 Debug: Checking if Astra can answer: {question}")

        if can_answer_question(question, mind_data):
            continue  # Skip resolved questions

        print(f"🔍 Debug: Flagging unresolved question: {question}")

        unresolved_questions.append({
            "question": question,
            "unresolved": True,
            "context": "Unresolved due to lack of knowledge at the moment."
        })

        valid_questions.append(question)

    mind_data["unresolved_questions"] = unresolved_questions
    return valid_questions  # ✅ Ensures only proper questions are returned


def can_answer_question(question, mind_data):
    """Determines if a question can be answered using Astra's stored knowledge."""
    stored_knowledge = [str(k).lower() for k in mind_data.get("stored_knowledge", [])]

    # Ensure question is a string before processing
    question = str(question) if not isinstance(question, str) else question.lower()

    # Debugging: Check if the question exists in the stored knowledge
    print(f"🔍 Checking stored knowledge for exact match: {question}")

    return any(question == knowledge.lower() for knowledge in stored_knowledge)  # ✅ Force exact match
