import random
import os
import sys
import asyncio
from fuzzywuzzy import fuzz

# ✅ Ensure Python knows where to find Astra’s core modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from astra_core.knowledge import knowledge_manager
from astra_core.reflection import generate_reflection
from astra_core.questions.question_manager import generate_questions
from astra_core.expansion import refine_knowledge
from astra_interfaces.influence import load_mind, save_mind
from astra_core.config_loader import load_config
from astra_core.config_loader import debug_log

general_config = load_config("general_config")


# ✅ Function: Ensure Mind Structure
def validate_mind_structure(mind_data):
    """Ensure `mind_data` has the correct structure."""
    mind_data.setdefault("self_reflections", [])
    mind_data.setdefault("self_questions", [])
    mind_data.setdefault("stored_knowledge", [])


async def process_reflection():
    """Generate, refine, and deepen Astra's reflections while ensuring responsiveness."""
    debug_log("Loading")  
    mind_data = load_mind()
    validate_mind_structure(mind_data)

    # ✅ Limit reflection processing
    recent_reflections = " ".join(mind_data["self_reflections"][-3:]) if mind_data["self_reflections"] else ""
    if len(recent_reflections) > 2500:
        recent_reflections = recent_reflections[:2500]

    # ✅ Extract unknown terms
    unknown_terms = knowledge_manager.extract_unknown_terms(recent_reflections)
    if unknown_terms:
        found_new_knowledge = knowledge_manager.retrieve_external_knowledge(unknown_terms)
        if found_new_knowledge:
            for knowledge in found_new_knowledge:
                if knowledge not in mind_data["stored_knowledge"]:
                    mind_data["stored_knowledge"].append(knowledge)
            save_mind(mind_data)

            # ✅ Reload mind
            reloaded_mind_data = load_mind()
            missing_knowledge = set(found_new_knowledge) - set(reloaded_mind_data["stored_knowledge"])
            if missing_knowledge:
                mind_data["stored_knowledge"].extend(missing_knowledge)
                save_mind(mind_data)

    new_reflection = generate_reflection(mind_data["stored_knowledge"], mind_data["self_reflections"])

    # 🔍 Debug: Check what we are returning
    if isinstance(new_reflection, dict):
        print(f"🚨 process_reflection() is returning a dict! {new_reflection}")
    elif not isinstance(new_reflection, str):
        print(f"🚨 process_reflection() returned an unexpected type: {type(new_reflection)}")

    # ✅ Ensure return is **always** a string
    if not new_reflection or not isinstance(new_reflection, str) or len(new_reflection.strip()) < 10:
        return "🤖 I'm still thinking... Try again in a moment!"

    expanded_reflection = expand_reflection(new_reflection)

    if expanded_reflection not in mind_data["self_reflections"]:
        mind_data["self_reflections"].append(expanded_reflection)

    save_mind(mind_data)

    print(f"🔍 Debug: process_reflection() final return type: {type(expanded_reflection)}")
    return str(expanded_reflection)  # ✅ Ensure we **always** return a string



def expand_reflection(reflection):
    """Deepens thoughts and ensures unique reflections."""
    expanded_reflection = reflection

    # ✅ Remove existing "Deeper Thought" before adding a new one
    expanded_reflection = "\n\n".join(
        line for line in expanded_reflection.split("\n\n") if not line.startswith("🔍 Deeper Thought:")
    )

    deeper_thought_templates = general_config["deeper_thought_templates"]
    deeper_thought = f"\n\n🔍 Deeper Thought: {random.choice(deeper_thought_templates)}"
    expanded_reflection += deeper_thought

    return expanded_reflection


def filter_knowledge(knowledge_list):
    """Ensure Astra keeps valuable knowledge while avoiding excessive duplicates."""
    filtered_knowledge = []
    seen = set()

    for entry in knowledge_list:
        if len(entry) < 10:
            continue  # ✅ Ignore very short junk entries

        key = entry.lower().strip()

        is_duplicate = False
        for existing in seen:
            similarity = fuzz.ratio(key, existing)

            if similarity >= 99:  # 🔥 Adjusted from 100% → 98% to allow slight variations
                is_duplicate = True
                break

        if not is_duplicate:
            seen.add(key)
            filtered_knowledge.append(entry)

    lost_percentage = (1 - (len(filtered_knowledge) / len(knowledge_list))) * 100

    if lost_percentage > 5:  # 🔥 Adjusted from 3% → 5% tolerance
        print(f"🚨 WARNING: Excessive filtering detected! Restoring original knowledge. Lost: {lost_percentage:.2f}%")
        return knowledge_list  # 🚀 Restore original knowledge if too much was removed

    return filtered_knowledge


# ✅ Debugging Function
def track_mind_data_changes(operation, mind_data):
    """Debugging function to track when `mind_data` changes."""
    if isinstance(mind_data, list):
        print(f"🚨 Error: `mind_data` has turned into a list! Contents: {mind_data}")
    elif isinstance(mind_data, dict):
        print(f"✅ `mind_data` is a dictionary. Keys: {list(mind_data.keys())}")


# ✅ Import `astra_schedule` only when running as the main script
if __name__ == "__main__":
    print("🧠 Astra is thinking...")
    from astra_core.astra_schedule.schedule import astra_schedule
    asyncio.run(process_reflection())  # ✅ Ensure async function is properly executed

