import time
import json
from astra_core.config_loader import load_config

# Load mood-related configurations
mood_config = load_config("mood_config")  # Load mood and emotional settings

class MoodManager:
    def __init__(self):
        self.current_mood = "neutral"  # Default mood
        self.curiosity_level = 1  # Base curiosity level (scaled)
        self.LOG_FILE = load_config("general_config")["log_file"]  # ✅ Fix: Log file should be part of the instance

    def log_mood_change(self):
        """Logs Astra's mood changes and curiosity shifts."""
        log_entry = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "mood": self.current_mood,
            "curiosity_level": self.curiosity_level
        }
        try:
            with open(self.LOG_FILE, "a") as f:  # ✅ Fix: Use `self.LOG_FILE`
                f.write(json.dumps(log_entry) + "\n")
        except Exception as e:
            print(f"🚨 Log Error: {e}")

    def set_mood(self, mood):
        """Set Astra's mood to a new state and log it."""
        print(f"🔍 Debug: Changing Astra's mood to {mood}")  # ✅ Debugging output
        self.current_mood = mood
        self.adjust_curiosity_level()
    
        # ✅ Fix: Call log_mood_change correctly
        print(f"🔍 Debug: Mood change logged - {self.current_mood}, Curiosity Level: {self.curiosity_level}")  # ✅ Debugging output
        self.log_mood_change()

    def adjust_curiosity_level(self):
        """Adjust curiosity based on current mood."""
        if self.current_mood in mood_config["moods"]:
            self.curiosity_level = mood_config["moods"][self.current_mood]["curiosity_factor"]
        else:
            self.curiosity_level = 1.0  # Default to neutral if not found

    def interact(self):
        """Handle interactions based on current mood."""
        if self.current_mood in mood_config["moods"]:
            self.curiosity_level = mood_config["moods"][self.current_mood]["curiosity_factor"]
        else:
            self.curiosity_level = 1.0  # Default to neutral if not found

    def reset_mood(self):
        """Reset mood to neutral."""
        self.set_mood("neutral")
    
    def bad_day(self):
        """Trigger a bad day scenario."""
        self.set_mood("sad")  # Change this to more specific triggers later
        print("Astra is having a bad day...")

    def good_day(self):
        """Trigger a good day scenario."""
        self.set_mood("happy")
        print("Astra is having a good day, full of curiosity!")

# Initialize mood manager
mood_manager = MoodManager()
