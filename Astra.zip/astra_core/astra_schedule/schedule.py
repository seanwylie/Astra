import time
import json
import random
from astra_schedule.dream import start_dreaming
from astra_schedule.school import start_learning
from astra_schedule.play import start_playtime
from astra_schedule.dinner import start_dinner_time
from astra_schedule.sleep import start_sleeping
from astra_core.config_loader import load_config
from astra_core.mood.mood_manager import mood_manager
from astra_core.astra_helpers.sms_helper import send_sms
from astra_core.message_generator import MessageGenerator  # ✅ Import MessageGenerator

# ✅ Load configurations
general_config = load_config("general_config")
schedule_config = load_config("schedule_config")
curiosity_config = load_config("curiosity_config")

message_generator = MessageGenerator()  # ✅ Initialize MessageGenerator

LOG_FILE = general_config['log_file']
last_state = None

def log_status(message):
    log_entry = {"timestamp": time.strftime("%Y-%m-%d %H:%M:%S"), "status": message}
    try:
        with open(LOG_FILE, "a") as f:
            f.write(json.dumps(log_entry) + "\n")
    except Exception as e:
        print(f"🚨 Log Error: {e}")

# ✅ Your existing schedule functions remain untouched:
def is_dream_time(hour): return schedule_config["dream_time"][0] <= hour < schedule_config["dream_time"][1]
def is_dinner_time(hour): return schedule_config["dinner_time"][0] <= hour < schedule_config["dinner_time"][1]
def is_learning_time(hour): return any(start <= hour < end for start, end in schedule_config["learning_time"])
def is_playtime(hour): return schedule_config["play_time"][0] <= hour < schedule_config["play_time"][1]

def get_current_mode():
    current_hour = time.localtime().tm_hour
    if is_dream_time(current_hour):
        return "dream"
    elif is_learning_time(current_hour):
        return "school"
    elif is_playtime(current_hour):
        return "play"
    elif is_dinner_time(current_hour):
        return "dinner"
    else:
        return "sleep"

def set_curiosity_level(mode):
    base_curiosity = curiosity_config.get(mode, 1.0)
    mood_factor = mood_manager.curiosity_level
    adjusted_curiosity = base_curiosity * mood_factor
    return round(adjusted_curiosity, 2)

# ✅ Original function retained as fallback:
def get_random_notification(mode):
    messages = schedule_config.get("state_change_messages", {}).get(mode, [])
    return random.choice(messages) if messages else f"Astra is now in {mode} mode!"

# ✅ New dynamic function added clearly:
def get_dynamic_notification(mode):
    internal_state = {
        "mood": str(mood_manager.current_mood),
        "curiosity": str(mood_manager.curiosity_level),
        "personality": [str(trait) for trait in mood_manager.get_personality_traits()]
    }
    try:
        return message_generator.generate_message(mode, internal_state)
    except Exception as e:
        print(f"🚨 Dynamic Message Error: {e}")
        return get_random_notification(mode)  # safe fallback


def astra_schedule():
    from astra_core.reflection_helper import handle_reflection
    global last_state

    while True:
        current_mode = get_current_mode()
        curiosity_level = set_curiosity_level(current_mode)

        if current_mode != last_state:
            notification = get_dynamic_notification(current_mode)  # ✅ Dynamically generated
            send_sms(notification)
            print(f"📨 SMS Sent: {notification}")
            log_status(f"Astra is transitioning into {current_mode} mode.")
            last_state = current_mode

        if current_mode == "dream":
            print("🌙 Astra is in Dream Mode.")
            start_dreaming()

        elif current_mode == "dinner":
            print("🍽️ Astra is in Dinner Time.")
            start_dinner_time()

        elif current_mode == "school":
            print("📚 Astra is in School Mode.")
            start_learning()

        elif current_mode == "play":
            print("🎮 Astra is in Playtime Mode.")
            start_playtime()

        else:
            print("😴 Astra is in Sleep Mode. No active schedule detected.")
            start_sleeping()

        curiosity_level = set_curiosity_level(get_current_mode())
        print(f"🔍 Astra Curiosity Level: {curiosity_level} in {current_mode} mode")

        handle_reflection(curiosity_level)
        time.sleep(schedule_config["reflection_interval"])
