import sys
import os

# Add the project root to the Python path to resolve imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pytest
import time
from unittest.mock import patch, MagicMock
from astra_core.mood.mood_manager import MoodManager
from astra_core.config_loader import load_config


@pytest.fixture
def mood_manager():
    """Fixture to create a fresh MoodManager instance with mocked memory & config."""
    
    # Load the real config dynamically
    mock_config = load_config("mood_config")

    # Create a mock mind state using config defaults
    mock_mind = {
        "last_mood": "neutral",
        "mood_score": 0.0,
        "curiosity_level": mock_config["moods"]["neutral"]["curiosity_factor"],
        "mood_history": {},
        "last_modification": {}
    }

    with patch("astra_core.mood.mood_manager.load_mind", return_value=mock_mind), \
         patch("astra_core.mood.mood_manager.save_mind"), \
         patch("astra_core.mood.mood_manager.load_config", return_value=mock_config):
        return MoodManager()


def test_initial_mood_state(mood_manager):
    """Ensure Astra restores or defaults to a valid mood state."""
    config = load_config("mood_config")
    assert mood_manager.get_current_mood() == "neutral"
    assert mood_manager.mood_score == 0.0
    assert mood_manager.get_curiosity() == config["moods"]["neutral"]["curiosity_factor"]


def test_mood_influence_positive(mood_manager):
    """Test positive mood influence adjustment."""
    config = load_config("mood_config")
    mood_manager.influence_mood("success")
    assert mood_manager.mood_score > 0.0
    assert mood_manager.get_current_mood() in config["moods"]


def test_mood_influence_negative(mood_manager):
    """Test negative mood influence adjustment."""
    config = load_config("mood_config")
    mood_manager.influence_mood("failure")
    assert mood_manager.mood_score < 0.0
    assert mood_manager.get_current_mood() in config["moods"]


def test_mood_score_bounds(mood_manager):
    """Ensure mood score respects min/max constraints from config."""
    config = load_config("mood_config")
    min_limit = config["mood_limits"]["min"]
    max_limit = config["mood_limits"]["max"]

    mood_manager.influence_mood("success", 10.0)  # Extreme boost
    assert mood_manager.mood_score == max_limit  # Should cap at max

    mood_manager.influence_mood("failure", -10.0)  # Extreme drop
    assert mood_manager.mood_score == min_limit  # Should cap at min


def test_mood_persistence(mood_manager):
    """Ensure Astra saves and restores her mood properly."""
    mood_manager.influence_mood("deep_reflection")
    previous_mood = mood_manager.get_current_mood()

    with patch("astra_core.mood.mood_manager.load_mind", return_value={"last_mood": previous_mood, "mood_score": 1.0}):
        new_instance = MoodManager()

    assert new_instance.get_current_mood() == previous_mood  # Should persist


def test_modify_mood_influence(mood_manager):
    """Ensure Astra can update mood influence values dynamically."""
    mood_manager.modify_mood_influence("success", 1.8)
    assert load_config("mood_config")["mood_influences"]["success"] == 1.8


def test_modify_mood_influence_respects_limits(mood_manager):
    """Ensure modifying mood influence respects dynamic min/max from config."""
    config = load_config("mood_config")
    min_limit = config["mood_limits"]["min"]
    max_limit = config["mood_limits"]["max"]

    mood_manager.modify_mood_influence("success", 5.0)
    assert mood_manager.mood_config["mood_influences"]["success"] == max_limit  # Should cap at max

    mood_manager.modify_mood_influence("failure", -5.0)
    assert mood_manager.mood_config["mood_influences"]["failure"] == min_limit  # Should cap at min


def test_update_mood_forces_update(mood_manager):
    """Ensure forcing mood update applies immediately."""
    mood_manager.influence_mood("success", 1.0)
    previous_mood = mood_manager.get_current_mood()
    mood_manager.update_mood(force=True)
    assert mood_manager.get_current_mood() == previous_mood  # Should be stable


def test_modify_curiosity_factor(mood_manager):
    """Ensure Astra can update curiosity factor values within limits."""
    mood_manager.modify_curiosity_factor("curious", 1.8)
    assert mood_manager.mood_config["moods"]["curious"]["curiosity_factor"] == 1.8


def test_modify_curiosity_respects_limits(mood_manager):
    """Ensure modifying curiosity factor respects limits from config."""
    config = load_config("mood_config")
    min_limit = config["curiosity_limits"]["min"]
    max_limit = config["curiosity_limits"]["max"]

    mood_manager.modify_curiosity_factor("curious", 5.0, force_override=True)
    assert mood_manager.mood_config["moods"]["curious"]["curiosity_factor"] == max_limit  # Should cap at max

    mood_manager.modify_curiosity_factor("curious", -5.0, force_override=True)
    assert mood_manager.mood_config["moods"]["curious"]["curiosity_factor"] == min_limit  # Should cap at min



def test_mood_thread_runs(mood_manager):
    """Ensure mood update thread runs without blocking execution."""
    assert mood_manager.last_mood_update > 0  # Should have been initialized


def test_get_mood_history(mood_manager):
    """Ensure Astra can retrieve her mood history."""
    assert isinstance(mood_manager.get_mood_history(), dict)


def test_get_curiosity(mood_manager):
    """Ensure Astra can retrieve her curiosity level."""
    assert isinstance(mood_manager.get_curiosity(), float)
