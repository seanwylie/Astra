import json

import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fuzzywuzzy import fuzz
from utils.json_loader import load_json_file
from astra_interfaces.influence import load_mind, save_mind

MIND_FILE_ORIG = "mind_file_parents.json"

print(f"🔍 Debug: MIND_FILE_ORIG Path → {MIND_FILE_ORIG}")  # ✅ Debug print


def safe_decode(text):
    """Ensure Unicode characters are properly decoded before storing."""
    try:
        return json.loads(f'"{text}"')  # Decodes Unicode safely
    except json.JSONDecodeError:
        return text  # If decoding fails, return the original text


def merge_knowledge(existing_knowledge, new_knowledge):
    """Merge new knowledge while preserving unique insights safely."""
    print(f"🔍 Debug: Incoming new knowledge items: {len(new_knowledge)}")
    print(f"🔍 Debug: Existing knowledge before merge: {len(existing_knowledge)}")

    # Maintain order while ensuring uniqueness
    knowledge_list = list(existing_knowledge)  
    knowledge_set = set(existing_knowledge)  # Lookup set for fast duplicate detection

    initial_count = len(knowledge_list)

    for item in new_knowledge:
        decoded_item = safe_decode(item)

        # Check if item is a duplicate with more relaxed fuzzy matching
        is_duplicate = any(fuzz.ratio(decoded_item.lower(), existing.lower()) > 75 for existing in knowledge_set)

        if is_duplicate:
            print(f"⚠ SKIPPED (potential false duplicate): {decoded_item}")
        else:
            knowledge_list.append(decoded_item)
            knowledge_set.add(decoded_item)  # Add to set for lookup
            print(f"➕ Added new knowledge: {decoded_item}")

    final_count = len(knowledge_list)
    print(f"🔍 After merging, stored knowledge count: {final_count}")

    if final_count < initial_count:
        print(f"⚠ WARNING: Knowledge count **decreased**, investigate merge logic!")

    return knowledge_list  # Maintain order while avoiding duplicates



def merge_structured_knowledge():
    """Merge insights from structured data into Astra's memory safely."""

    # ✅ Lazy import to prevent circular dependency
    from astra_core.knowledge_manager import merge_knowledge

    mind_data = load_mind()
    structured_data = load_json_file(MIND_FILE_ORIG, {"insights": []})

    print(f"🔍 Before merging, stored knowledge count: {len(mind_data['stored_knowledge'])}")

    if "insights" in structured_data:
        structured_knowledge = [entry["insight"] for entry in structured_data["insights"]]

        # ✅ Reload mind data before merging to prevent overwriting
        reloaded_mind_data = load_mind()
        print(f"🔍 Reloaded mind data before merge. Stored Knowledge: {len(reloaded_mind_data['stored_knowledge'])}")

        reloaded_mind_data["stored_knowledge"] = merge_knowledge(reloaded_mind_data["stored_knowledge"], structured_knowledge)

        # ✅ Lazy import to prevent circular dependency
        from astra_interfaces.influence import save_mind

        # ✅ Save the updated mind data
        print(f"🔍 Debug: Saving mind data with {len(reloaded_mind_data['stored_knowledge'])} knowledge items")
        save_mind(reloaded_mind_data)

        # ✅ Reload after saving to verify persistence
        saved_mind_data = load_mind()
        print(f"🔍 After saving & reloading, stored knowledge count: {len(saved_mind_data['stored_knowledge'])}")

        if len(saved_mind_data['stored_knowledge']) < len(reloaded_mind_data['stored_knowledge']):
            print(f"⚠ WARNING: Knowledge loss detected after saving! Before: {len(reloaded_mind_data['stored_knowledge'])}, After: {len(saved_mind_data['stored_knowledge'])}")

    print(f"🔹 Knowledge merge complete! Total knowledge items: {len(saved_mind_data['stored_knowledge'])}")
    return saved_mind_data


# ✅ Prevent execution on import to avoid circular dependency issues
if __name__ == "__main__":
    merge_structured_knowledge()
